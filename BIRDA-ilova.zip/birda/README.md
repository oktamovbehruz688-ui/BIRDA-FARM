# BIRDA — Ferma boshqaruv ilovasi

Mobil qurilmalarga mos React + Vite ilovasi. Interfeys o‘zbek tilida.

## Ishga tushirish

1. Node.js 18 yoki undan yangiroq versiyasini o‘rnating.
2. Loyiha papkasida terminal oching.
3. `npm install` buyrug‘ini bajaring.
4. `npm run dev` buyrug‘ini bajaring.
5. Terminal ko‘rsatgan mahalliy manzilni brauzerda oching.

## Hozirgi imkoniyatlar

- 7 ta hayvon toifasi va zot tanlash
- Hayvon guruhlarini qo‘shish va o‘chirish
- Ombor mahsulotlarini kiritish
- Sotuv va xarajatlarni qayd etish
- Asosiy ko‘rsatkichlar va hisobotlar
- Ma’lumotlarni brauzerning localStorage xotirasida saqlash

## Muhim eslatma

Bu birinchi ishlaydigan prototip. Ma’lumotlar hozircha faqat shu brauzer va qurilmada saqlanadi. Bir nechta foydalanuvchi, qurilmalararo sinxronlash, xavfsiz kirish va bulutli zaxira uchun Supabase ulanishi keyingi bosqichda qo‘shilishi kerak. Hisobotlar faqat foydalanuvchi kiritgan sotuv va xarajatlar asosida hisoblanadi.
